This projects requires java-7 with java-fx (all jars located in /dist/libs).

To run the test program:
execute /dist/OdoboChallenge.jar

Project sources are located in /project dir.
