This projects requires java-7 with java-fx.
To run the test program:
execute /dist/OdoboChallenge.jar

Project sources are located in /project dir.
